from setuptools import setup, find_packages
import os

# Safe README read
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", encoding="utf-8") as f:
        long_description = f.read()

setup(
    name="lynkio",
    version="1.0.1",
    author="Lynk Team & Alex Austin",
    author_email="benmap40@gmail.com",  # Replace with actual contact
    description=(
        "Lynkio – Real‑time event engine with native HTTP routing. "
        "Pure Python, standard library only."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/pythos-team/lynk",  # Placeholder – update as needed
    license="MIT",
    packages=find_packages(),
    # Core dependencies: none (pure Python, standard library only)
    install_requires=[],
    # Optional development dependencies
    extras_require={
    },
    entry_points={
        "console_scripts": [
            "lynk = lynk:cli_main",   # Assumes a cli_main function in lynk/__init__.py or lynk.py
        ],
    },
    python_requires=">=3.7",
    zip_safe=False,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Operating System :: OS Independent",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "Topic :: Internet :: WWW/HTTP :: WSGI",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords=[
        "real-time",
        "event-engine",
        "http",
        "websocket",
        "asyncio",
        "routing",
        "middleware",
        "pubsub",
        "server",
    ],
    project_urls={
        "Bug Reports": "https://github.com/pythos-team/lynk/issues",
        "Source": "https://github.com/pythos-team/lynk",
        "Documentation": "https://github.com/pythos-team/lynk#readme",
    },
)